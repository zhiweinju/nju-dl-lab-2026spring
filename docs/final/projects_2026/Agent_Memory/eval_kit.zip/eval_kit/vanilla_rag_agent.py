"""
Vanilla RAG 基线：
  - 把原始对话按"每轮一个 chunk"切分
  - 用 embedding 模型对每个 chunk 编码
  - 回答问题时按余弦相似度检索 top-k，塞进 prompt

这是一个**故意做得很弱**的基线：
  - 直接把对话轮次当记忆，不做任何抽取/摘要/更新
  - 没有记忆管理机制（没有遗忘、没有去重、没有冲突处理）
你的系统应当在此基础上有明显提升，否则说明记忆模块没有发挥作用。

使用方式：
    # 1. 启动一个 chat LLM（例如 Qwen2.5-7B-Instruct），监听 LLM_BASE_URL
    # 2. 启动一个 embedding 模型（例如 bge-small-zh-v1.5），监听 EMBED_BASE_URL
    # 3. 运行：
    python run_generation.py --eval_set eval_set.json \
        --agent vanilla_rag_agent:VanillaRAGAgent \
        --output predictions_rag.json
"""

import os
import numpy as np
from llm_client import LLMClient


class VanillaRAGAgent:
    def __init__(self, top_k: int = 5):
        # 生成用的 LLM：从默认环境变量读配置
        self.llm = LLMClient()
        # embedding 用的客户端：可以复用同一个 vLLM 服务（需支持 embeddings 接口），
        # 也可以指向单独部署的 bge 服务，通过 EMBED_BASE_URL / EMBED_MODEL 控制
        self.embed_client = LLMClient(
            base_url=os.getenv("EMBED_BASE_URL", os.getenv("LLM_BASE_URL")),
            model=os.getenv("EMBED_MODEL", "BAAI/bge-small-zh-v1.5"),
        )
        self.top_k = top_k
        self.chunks: list[str] = []
        self.embeddings: np.ndarray | None = None

    def ingest(self, conversation: dict) -> None:
        # 一个 chunk = 一条对话轮次，前面加上时间和说话人作为上下文标识
        chunks = []
        for sess in conversation["sessions"]:
            for turn in sess["turns"]:
                chunks.append(
                    f"[{sess['date_time']}] {turn['speaker']}: {turn['text']}"
                )
        self.chunks = chunks

        # 批量编码所有 chunk
        vecs = self.embed_client.embed(chunks, model=self.embed_client.model)
        self.embeddings = np.array(vecs, dtype=np.float32)
        # L2 归一化：归一化后点积等价于余弦相似度，后面检索更快
        norms = np.linalg.norm(self.embeddings, axis=1, keepdims=True) + 1e-8
        self.embeddings /= norms

    def _retrieve(self, query: str, k: int) -> list[str]:
        """对 query 编码后做余弦相似度检索，返回 top-k 的原文 chunk。"""
        qvec = np.array(self.embed_client.embed(query)[0], dtype=np.float32)
        qvec /= np.linalg.norm(qvec) + 1e-8
        sims = self.embeddings @ qvec                  # 归一化后点积 = 余弦相似度
        idx = np.argsort(-sims)[:k]                    # 取最相似的 k 个
        return [self.chunks[i] for i in idx]

    def answer(self, question: str) -> str:
        retrieved = self._retrieve(question, self.top_k)
        ctx = "\n".join(retrieved)
        # prompt 保持英文以匹配 LoCoMo 原生语言
        prompt = (
            "You are answering a question about a past conversation. "
            "Use only the retrieved dialogue snippets below. Keep the answer short "
            "(a phrase or one sentence). If the snippets do not contain the answer, "
            "reply 'unknown'.\n\n"
            f"=== Retrieved snippets ===\n{ctx}\n\n"
            f"=== Question ===\n{question}\n\n"
            "=== Answer ==="
        )
        return self.llm.generate(prompt, max_tokens=64).strip()
